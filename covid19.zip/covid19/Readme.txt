Simple machine learning project where we use random data.it's give us probability that patient is infected by corona virus or not.

run program

1. python dataTraining.py
2. python main.py 