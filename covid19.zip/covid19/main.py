from flask import Flask,render_template,request
import pickle
app = Flask(__name__)

file = open('model.pkl','rb')
lr = pickle.load(file)
file.close()

@app.route('/', methods=["GET","POST"])
def hello_world():
    if request.method == "POST":
        myValue = request.form
        fever = int(myValue["fever"])
        age = int(myValue["age"])
        BodyPain = int(myValue["BodyPain"])
        RunnyNose = int(myValue["RunnyNose"])
        BreathProb = int(myValue["BreathProb"])
        # inference code

        inputFeatures = [fever, BodyPain, age, RunnyNose, BreathProb]
        infProb = lr.predict_proba([inputFeatures])[0][1]
        print(infProb)
        return render_template('show.html', inf=round(infProb*100))


    return render_template('index.html')
    #return 'Infection Prob., is :' + str(infProb)
if __name__ == "__main__":
    app.run(debug=True)